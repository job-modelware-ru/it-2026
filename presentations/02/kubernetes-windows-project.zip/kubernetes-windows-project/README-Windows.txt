Kubernetes demo project for Windows / PowerShell

Contents:
- src\kind-config.yaml: kind cluster configuration (1 control-plane, 2 workers)
- src\manifests\namespace.yaml
- src\manifests\deployment.yaml
- src\manifests\service.yaml
- src\manifests\client.yaml
- src\scripts\setup.ps1: downloads images and creates/prepares the cluster
- src\scripts\cleanup.ps1: deletes the kind cluster

Before starting:
1. Install Docker Desktop, kubectl, kind and Windows Terminal.
2. Start Docker Desktop and wait until its engine is running.
3. Open PowerShell in this src folder.
4. If PowerShell blocks local scripts, run this once in the current PowerShell window:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
5. Run:
   .\scripts\setup.ps1

After setup, check:
   kubectl get nodes -o wide
   kubectl get pods -n kube-system -o wide

Then follow the practical demo instructions. The demo Deployment, Service and client
are applied during the corresponding steps, not automatically during setup.

To remove the cluster after the demo:
   .\scripts\cleanup.ps1

Note: this is a generated starter project based on the uploaded practical-part PDF.
The kind cluster uses one etcd instance, so it demonstrates etcd keys but not a
multi-member Raft quorum.
