$ErrorActionPreference = 'Stop'
kind delete cluster --name k8s-demo
if ($LASTEXITCODE -ne 0) { throw 'Could not delete kind cluster k8s-demo.' }
