$ErrorActionPreference = 'Stop'

Write-Host 'Checking Docker...'
docker version
if ($LASTEXITCODE -ne 0) { throw 'Docker is not available. Start Docker Desktop and try again.' }

Write-Host 'Downloading images...'
docker pull nginx:1.25
if ($LASTEXITCODE -ne 0) { throw 'Failed to pull nginx:1.25' }
docker pull nginx:1.27
if ($LASTEXITCODE -ne 0) { throw 'Failed to pull nginx:1.27' }
docker pull busybox:1.36
if ($LASTEXITCODE -ne 0) { throw 'Failed to pull busybox:1.36' }

$clusters = kind get clusters
if ($LASTEXITCODE -ne 0) { throw 'Could not query kind clusters.' }
if ($clusters -contains 'k8s-demo') {
    Write-Host 'Cluster k8s-demo already exists; reusing it.'
} else {
    Write-Host 'Creating kind cluster...'
    kind create cluster --name k8s-demo --config .\kind-config.yaml
    if ($LASTEXITCODE -ne 0) { throw 'Failed to create kind cluster.' }
}

Write-Host 'Loading images into kind nodes...'
kind load docker-image nginx:1.25 nginx:1.27 busybox:1.36 --name k8s-demo
if ($LASTEXITCODE -ne 0) { throw 'Failed to load images into kind.' }

kubectl config use-context kind-k8s-demo
if ($LASTEXITCODE -ne 0) { throw 'Could not select kind-k8s-demo context.' }
kubectl apply -f .\manifests\namespace.yaml
if ($LASTEXITCODE -ne 0) { throw 'Failed to create demo namespace.' }
kubectl config set-context --current --namespace=demo
if ($LASTEXITCODE -ne 0) { throw 'Could not set default namespace.' }

Write-Host 'Cluster nodes:'
kubectl get nodes -o wide
Write-Host 'Setup completed. You can now follow the demo steps.'
