"""Start both local Flask apps from one terminal. Stop with Ctrl+C."""
import subprocess
import sys
import time
from pathlib import Path

PROJECT = Path(__file__).resolve().parent


def main():
    procs = [
        subprocess.Popen([sys.executable, "app.py", "portal"], cwd=PROJECT),
        subprocess.Popen([sys.executable, "app.py", "vault"], cwd=PROJECT),
    ]
    print("\nIdentity Lab: open http://localhost:5001 (Keycloak should already run)", flush=True)
    try:
        while all(proc.poll() is None for proc in procs):
            time.sleep(0.5)
        print("One of the applications stopped. Check messages above.", flush=True)
    except KeyboardInterrupt:
        print("\nStopping both applications...", flush=True)
    finally:
        for proc in procs:
            if proc.poll() is None:
                proc.terminate()
        for proc in procs:
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()


if __name__ == "__main__":
    main()
