'use strict';

const probeButtons = [...document.querySelectorAll('[data-probe]')];
const responseStatus = document.querySelector('#response-status');
const responseOutput = document.querySelector('#response-json');
const importButton = document.querySelector('#import-tasks');
const importMessage = document.querySelector('#import-message');
const importedTasks = document.querySelector('#imported-tasks');

function showStatus(code) {
  responseStatus.textContent = `HTTP ${code}`;
  responseStatus.className = `response-status ${code === 200 ? 'good' : code === 403 ? 'warn' : 'bad'}`;
}

async function probe(kind) {
  const res = await fetch(`/probe/${kind}`, {headers: {Accept: 'application/json'}, credentials: 'same-origin'});
  const data = await res.json();
  return {code: data.status ?? res.status, data};
}

for (const button of probeButtons) {
  button.addEventListener('click', async () => {
    probeButtons.forEach(node => node.classList.remove('selected'));
    button.classList.add('selected');
    responseStatus.textContent = 'Запрос…';
    responseOutput.textContent = 'Обращаемся к защищённому API TaskBox…';
    try {
      const {code, data} = await probe(button.dataset.probe);
      showStatus(code);
      responseOutput.textContent = JSON.stringify({
        request: `GET /api/notes — ${data.label ?? button.dataset.probe}`,
        http_status: code,
        ...data.response,
      }, null, 2);
    } catch {
      responseStatus.textContent = 'Ошибка';
      responseStatus.className = 'response-status bad';
      responseOutput.textContent = 'Не удалось связаться с приложением.';
    }
  });
}

if (importButton) {
  importButton.addEventListener('click', async () => {
    importButton.disabled = true;
    importMessage.textContent = 'Dayboard обращается к API TaskBox с Access Token…';
    importedTasks.replaceChildren();
    try {
      const {code, data} = await probe('access');
      if (code !== 200 || !Array.isArray(data.response?.notes)) {
        importMessage.textContent = `HTTP ${code} — доступ не получен. Проверьте настройки audience и срок действия токена.`;
        return;
      }
      const notes = data.response.notes;
      importMessage.textContent = `HTTP 200 · TaskBox вернул ${notes.length} задач(и). Данные получены из приложения B.`;
      for (const note of notes) {
        const row = document.createElement('div');
        row.className = `imported-task ${note.done ? 'complete' : ''}`;
        const mark = document.createElement('span');
        mark.className = 'task-check';
        mark.textContent = note.done ? '✓' : '○';
        const info = document.createElement('div');
        const title = document.createElement('strong');
        title.textContent = note.title;
        const category = document.createElement('small');
        category.textContent = `${note.category} · ${note.done ? 'Готово' : 'В процессе'}`;
        info.append(title, category);
        row.append(mark, info);
        importedTasks.append(row);
      }
      if (!notes.length) {
        const hint = document.createElement('p');
        hint.textContent = 'Задач пока нет. Добавьте одну в TaskBox.';
        importedTasks.append(hint);
      }
    } catch {
      importMessage.textContent = 'Ошибка соединения с TaskBox. Проверьте, что приложение B запущено.';
    } finally {
      importButton.disabled = false;
    }
  });
}
