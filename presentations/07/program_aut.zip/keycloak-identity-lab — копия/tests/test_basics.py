"""Offline smoke tests; Keycloak is not needed."""
import pytest
from app import create_app, decoded_for_display, list_tasks


@pytest.fixture(autouse=True)
def configure(monkeypatch, tmp_path):
    values = {
        "KEYCLOAK_ISSUER": "http://localhost:8080/realms/example",
        "PORTAL_CLIENT_ID": "clientA", "PORTAL_CLIENT_SECRET": "test-secret-a",
        "VAULT_CLIENT_ID": "clientB", "VAULT_CLIENT_SECRET": "test-secret-b",
        "PORTAL_SESSION_SECRET": "test-session-secret-a",
        "VAULT_SESSION_SECRET": "test-session-secret-b",
        "DEMO_DATABASE_PATH": str(tmp_path / "tasks.sqlite3"),
        "API_REQUIRED_ROLE": "",
    }
    for name, value in values.items():
        monkeypatch.setenv(name, value)


def test_two_independent_clients_and_pages():
    a = create_app("portal")
    b = create_app("vault")
    assert a.config["SESSION_COOKIE_NAME"] != b.config["SESSION_COOKIE_NAME"]
    a_page = a.test_client().get("/")
    b_page = b.test_client().get("/")
    assert a_page.status_code == 200
    assert b_page.status_code == 200
    assert "Dayboard" in a_page.get_data(as_text=True) or "dayboard" in a_page.get_data(as_text=True)
    assert "TaskBox" in b_page.get_data(as_text=True) or "taskbox" in b_page.get_data(as_text=True)


def test_protected_api_denies_anonymous():
    b = create_app("vault")
    res = b.test_client().get("/api/notes")
    assert res.status_code == 401
    assert res.get_json()["error"] == "missing_token"


def test_tasks_are_isolated_per_keycloak_sub():
    first = list_tasks("user-one")
    second = list_tasks("user-two")
    assert len(first) == len(second) == 3
    assert {t["id"] for t in first}.isdisjoint({t["id"] for t in second})
    assert list_tasks("user-one") == first  # No duplicate seeds


def test_note_changes_require_session():
    b = create_app("vault")
    res = b.test_client().post("/notes/add", data={"title": "Secret"})
    assert res.status_code == 401


def test_unverified_jwt_is_not_used_for_authentication():
    assert decoded_for_display("not-a-jwt")["format"]


def test_taskbox_user_can_add_task_with_csrf():
    from app import _TOKEN_STORES
    b = create_app("vault")
    sid = "test-logged-in-user"
    _TOKEN_STORES["vault"][sid] = {
        "profile": {"sub": "user-demo", "name": "Demo"},
        "token": {},
    }
    try:
        client = b.test_client()
        with client.session_transaction() as s:
            s["sid"] = sid
            s["csrf"] = "valid-form-csrf"
        res = client.post("/notes/add", data={
            "csrf": "valid-form-csrf", "title": "Test from TaskBox", "category": "Учёба",
        })
        assert res.status_code == 302
        assert any(task["title"] == "Test from TaskBox" for task in list_tasks("user-demo"))
        invalid = client.post("/notes/add", data={"csrf": "incorrect", "title": "Bad"})
        assert invalid.status_code == 403
    finally:
        _TOKEN_STORES["vault"].pop(sid, None)
