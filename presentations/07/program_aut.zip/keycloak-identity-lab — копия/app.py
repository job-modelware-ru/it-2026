"""Dayboard + TaskBox: educational OAuth 2.0 and OpenID Connect demonstration.

Run: python start_demo.py
Two independent Flask OIDC clients registered in the SAME Keycloak realm.
TaskBox additionally exposes a JWT-protected API; its data belongs to Keycloak
users (identified by the verified `sub` claim), not to client A.
"""
from __future__ import annotations

import argparse
import os
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

import jwt
import requests
from authlib.integrations.flask_client import OAuth
from dotenv import load_dotenv
from flask import Flask, abort, jsonify, redirect, render_template, request, session, url_for
from jwt import PyJWKClient
from jwt.exceptions import InvalidTokenError, PyJWKClientError

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

# The cookie contains only a random SID. OAuth tokens live on the server.
# In-memory storage is intentional for a single-computer classroom demo.
_TOKEN_STORES: dict[str, dict[str, dict]] = {"portal": {}, "vault": {}}
DEMO_NOTES = [
    ("Подготовить презентацию", "Учёба", 1),
    ("Проверить доступ через OAuth", "Разработка", 0),
    ("Показать единый вход SSO", "Демонстрация", 0),
]
DISPLAY_CLAIMS = (
    "iss", "sub", "aud", "azp", "preferred_username", "name", "email",
    "scope", "iat", "exp", "auth_time", "typ",
)


def env_required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value or value.startswith("replace-"):
        raise RuntimeError(f"Не задано {name} в .env (см. .env.example)")
    return value


def decoded_for_display(raw_jwt: str | None) -> dict:
    """Unsafe decode is ONLY used to display a few claims, never for auth."""
    if not raw_jwt:
        return {}
    try:
        claims = jwt.decode(raw_jwt, options={"verify_signature": False})
        return {k: claims[k] for k in DISPLAY_CLAIMS if k in claims}
    except (InvalidTokenError, ValueError):
        return {"format": "Токен не является JWT"}


def pretty_time(value: int | float | None) -> str:
    if not value:
        return "—"
    return datetime.fromtimestamp(value, timezone.utc).strftime("%d.%m.%Y %H:%M UTC")


def database_path() -> Path:
    return Path(os.getenv("DEMO_DATABASE_PATH", str(ROOT / "taskbox.sqlite3"))).resolve()


def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(database_path(), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 10000")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS tasks ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "owner_sub TEXT NOT NULL, title TEXT NOT NULL, "
        "category TEXT NOT NULL DEFAULT 'Личное', done INTEGER NOT NULL DEFAULT 0)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS demo_users (owner_sub TEXT PRIMARY KEY)"
    )
    conn.commit()
    return conn


def ensure_demo_tasks(owner_sub: str) -> None:
    """Seed each user once; never overwrite tasks they add or delete."""
    with connect_db() as db:
        db.execute("BEGIN IMMEDIATE")
        exists = db.execute(
            "SELECT 1 FROM demo_users WHERE owner_sub = ?", (owner_sub,)
        ).fetchone()
        if not exists:
            db.executemany(
                "INSERT INTO tasks (owner_sub,title,category,done) VALUES (?,?,?,?)",
                [(owner_sub, title, category, done) for title, category, done in DEMO_NOTES],
            )
            db.execute("INSERT INTO demo_users(owner_sub) VALUES(?)", (owner_sub,))


def list_tasks(owner_sub: str) -> list[dict]:
    ensure_demo_tasks(owner_sub)
    with connect_db() as db:
        result = db.execute(
            "SELECT id,title,category,done FROM tasks WHERE owner_sub = ? ORDER BY id DESC",
            (owner_sub,),
        ).fetchall()
    return [dict(id=r["id"], title=r["title"], category=r["category"],
                 done=bool(r["done"])) for r in result]


def create_app(which: str) -> Flask:
    if which not in ("portal", "vault"):
        raise ValueError("which must be portal or vault")

    issuer = env_required("KEYCLOAK_ISSUER").rstrip("/")
    portal_id = env_required("PORTAL_CLIENT_ID")
    vault_id = env_required("VAULT_CLIENT_ID")
    client_id = portal_id if which == "portal" else vault_id
    client_secret = env_required("PORTAL_CLIENT_SECRET" if which == "portal" else "VAULT_CLIENT_SECRET")
    secret_key = env_required("PORTAL_SESSION_SECRET" if which == "portal" else "VAULT_SESSION_SECRET")
    portal_port = int(os.getenv("PORTAL_PORT", "5001"))
    vault_port = int(os.getenv("VAULT_PORT", "5002"))
    portal_url = f"http://localhost:{portal_port}"
    vault_url = f"http://localhost:{vault_port}"
    api_role = os.getenv("API_REQUIRED_ROLE", "").strip()

    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=secret_key,
        SESSION_COOKIE_NAME=f"identity_lab_{which}",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=False,  # HTTP localhost demo ONLY.
    )
    oauth = OAuth(app)
    oauth.register(
        name="keycloak",
        client_id=client_id,
        client_secret=client_secret,
        server_metadata_url=f"{issuer}/.well-known/openid-configuration",
        client_kwargs={"scope": "openid profile email tasks.read" if which == "portal" else "openid profile email"},
        code_challenge_method="S256",
    )
    jwks = PyJWKClient(f"{issuer}/protocol/openid-connect/certs", cache_keys=True)
    store = _TOKEN_STORES[which]

    def local_login() -> dict | None:
        sid = session.get("sid")
        return store.get(sid) if sid else None

    def clear_local_login() -> dict | None:
        old = local_login()
        sid = session.get("sid")
        if sid:
            store.pop(sid, None)
        session.clear()
        return old

    @app.get("/")
    def home():
        record = local_login()
        profile = record["profile"] if record else None
        token = record["token"] if record else {}
        access_claims = decoded_for_display(token.get("access_token"))
        notes = list_tasks(profile["sub"]) if which == "vault" and profile else []
        if which == "vault" and profile and "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(32)
        return render_template(
            "dayboard.html" if which == "portal" else "taskbox.html",
            which=which, profile=profile,
            realm=issuer.rsplit("/", 1)[-1],
            client_id=client_id, vault_id=vault_id,
            portal_url=portal_url, vault_url=vault_url,
            id_claims=decoded_for_display(token.get("id_token")),
            access_claims=access_claims,
            access_expires=pretty_time(access_claims.get("exp")),
            access_expired=bool(access_claims.get("exp") and access_claims["exp"] < time.time()),
            notes=notes, csrf=session.get("csrf", ""), api_role=api_role,
        )

    @app.get("/login")
    def login():
        # Authlib provides OIDC nonce/state tracking and PKCE S256.
        return oauth.keycloak.authorize_redirect(url_for("callback", _external=True))

    @app.get("/callback")
    def callback():
        try:
            token = oauth.keycloak.authorize_access_token()
            print(
                "Токены получены:",
                "ID Token:", "id_token" in token,
                "Access Token:", "access_token" in token,
                
                flush=True
            )
            verified_profile = dict(token.get("userinfo") or {})
            if not verified_profile.get("sub"):
                raise ValueError("Keycloak не вернул проверенный sub")
        except Exception:
            app.logger.exception("OIDC callback failed")
            return (
                "<h2>Не удалось завершить вход</h2>"
                "<p>Проверьте realm, client secret, redirect URI и логи Flask.</p>"
                '<p><a href="/">Вернуться</a></p>',
                400,
            )
        clear_local_login()
        sid = secrets.token_urlsafe(32)
        store[sid] = {"token": dict(token), "profile": verified_profile}
        session["sid"] = sid
        return redirect(url_for("home"))

    @app.get("/logout")
    def logout():
        clear_local_login()
        return redirect(url_for("home"))

    @app.get("/logout-sso")
    def logout_sso():
        old = clear_local_login()
        params = {"client_id": client_id,
                  "post_logout_redirect_uri": url_for("home", _external=True)}
        if old and old["token"].get("id_token"):
            params["id_token_hint"] = old["token"]["id_token"]
        return redirect(f"{issuer}/protocol/openid-connect/logout?{urlencode(params)}")

    @app.get("/probe/<kind>")
    def probe(kind: str):
        """A -> B, server-to-server; never expose full bearer tokens in browser."""
        if which != "portal":
            return jsonify({"error": "not_available_in_taskbox"}), 404
        if kind not in ("none", "id", "access"):
            return jsonify({"error": "unknown_demo_case"}), 404
        record = local_login()
        if kind != "none" and not record:
            return jsonify({"error": "Сначала войдите через Keycloak"}), 401
        raw = (record["token"].get("id_token") if kind == "id" else
               record["token"].get("access_token") if kind == "access" else None)
        headers = {"Authorization": f"Bearer {raw}"} if raw else {}
        try:
            result = requests.get(f"{vault_url}/api/notes", headers=headers, timeout=5)
            try:
                payload = result.json()
            except ValueError:
                payload = {"message": "API вернул не JSON"}
            return jsonify({
                "test": kind, "status": result.status_code,
                "response": payload,
                "label": {"none": "Без токена", "id": "ID Token", "access": "Access Token"}[kind],
            })
        except requests.RequestException:
            return jsonify({
                "test": kind, "status": 503,
                "response": {"error": "TaskBox недоступен. Убедитесь, что запущен порт 5002"},
                "label": kind,
            }), 503

    if which == "vault":
        def require_web_login():
            current = local_login()
            if not current:
                abort(401)
            provided = request.form.get("csrf", "")
            expected = session.get("csrf", "")
            if not expected or not secrets.compare_digest(provided, expected):
                abort(403)
            return current["profile"]["sub"]

        @app.post("/notes/add")
        def add_task():
            owner_sub = require_web_login()
            title = request.form.get("title", "").strip()
            category = request.form.get("category", "Личное")
            if not title or len(title) > 120:
                return "Название задачи должно содержать от 1 до 120 символов", 400
            if category not in ("Личное", "Учёба", "Работа", "Разработка", "Демонстрация"):
                category = "Личное"
            ensure_demo_tasks(owner_sub)
            with connect_db() as db:
                db.execute(
                    "INSERT INTO tasks (owner_sub,title,category,done) VALUES(?,?,?,0)",
                    (owner_sub, title, category),
                )
            return redirect(url_for("home", _anchor="tasks"))

        @app.post("/notes/toggle/<int:task_id>")
        def toggle_task(task_id: int):
            owner_sub = require_web_login()
            with connect_db() as db:
                db.execute(
                    "UPDATE tasks SET done=CASE done WHEN 1 THEN 0 ELSE 1 END "
                    "WHERE id=? AND owner_sub=?", (task_id, owner_sub),
                )
            return redirect(url_for("home", _anchor="tasks"))

        @app.post("/notes/delete/<int:task_id>")
        def delete_task(task_id: int):
            owner_sub = require_web_login()
            with connect_db() as db:
                db.execute("DELETE FROM tasks WHERE id=? AND owner_sub=?", (task_id, owner_sub))
            return redirect(url_for("home", _anchor="tasks"))

        @app.get("/api/notes")
        def protected_notes():
            auth = request.headers.get("Authorization", "")
            if not auth.startswith("Bearer ") or not auth[7:].strip():
                return jsonify({"error": "missing_token", "detail": "Нужен Bearer Access Token"}), 401
            raw = auth[7:].strip()
            try:
                key = jwks.get_signing_key_from_jwt(raw).key
                claims = jwt.decode(
                    raw, key, algorithms=["RS256"], issuer=issuer,
                    audience=vault_id,
                    options={"require": ["exp", "iss", "aud", "sub"]},
                )
            except (InvalidTokenError, PyJWKClientError, ValueError):
                return jsonify({
                    "error": "invalid_token",
                    "detail": "Не прошла проверка подписи, срока, issuer или audience",
                }), 401
            except requests.RequestException:
                return jsonify({"error": "identity_provider_unavailable"}), 503
            # Keycloak-specific token kind: Access Tokens have payload typ='Bearer'.
            if claims.get("typ") != "Bearer":
                return jsonify({"error": "wrong_token_type",
                                "detail": "API принимает Access Token, а не ID Token"}), 401
            scopes = claims.get("scope", "").split()

            if "tasks.read" not in scopes:
                return jsonify({
                    "error": "insufficient_scope",
                    "detail": "Для чтения задач требуется tasks.read"
                }), 403
            if api_role:
                roles = claims.get("resource_access", {}).get(vault_id, {}).get("roles", [])
                if api_role not in roles:
                    return jsonify({"error": "insufficient_permissions",
                                    "detail": f"Нужна роль {api_role}"}), 403
            owner_sub = claims["sub"]
            notes = list_tasks(owner_sub)
            return jsonify({
                "message": "Доступ к защищённому API разрешён",
                "authenticated_user": claims.get("preferred_username", owner_sub),
                "audience": vault_id,
                "notes": notes,
            })

    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run one of the demo apps")
    parser.add_argument("app", choices=["portal", "vault"])
    which = parser.parse_args().app
    port = int(os.getenv("PORTAL_PORT", "5001") if which == "portal" else os.getenv("VAULT_PORT", "5002"))
    print(f"Starting {which} on http://localhost:{port}")
    create_app(which).run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
